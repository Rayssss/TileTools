﻿#include "dialog2.h"
#include "ui_dialog2.h"
#include "QPixmap"
#include"QPainter"
#include"QPaintEvent"
#include"QDebug"
#include"mainwindow.h"
#include"QXmlStreamAttribute"
#include"QProcess"
#include"QByteArray"
#include"QThread"
#include"QStandardItemModel"
#include"QTextCodec"
#include"about.h"
int MainWindow::x;
int MainWindow::y;
int MainWindow::flag;
int MainWindow::flag2;
Dialog2::Dialog2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog2)

{
    ui->setupUi(this);
    icon.load("E:/Qt/TileTools/logo4.png");


    ui->pushButton_2->setIcon(icon);
    ui->pushButton->setVisible(false);
    ui->pushButton_3->setVisible(false);
    ui->checkBox_2->setFont(QFont("Timers" , 10 ,  QFont::Bold));
    ui->checkBox->setFont(QFont("Timers" , 10 ,  QFont::Bold));
    ui->settext2->setFont(QFont("Timers" , 10 ,  QFont::Bold));
    ui->settext1->setFont(QFont("Timers" , 10 ,  QFont::Bold));
    ui->textcolor->setFont(QFont("Timers" , 10 ,  QFont::Bold));
    ui->textvisible->setFont(QFont("Timers" , 10 ,  QFont::Bold));
    ui->label_2->setFont(QFont("Timers" , 10 ,  QFont::Bold));
    ui->label->setFont(QFont("Timers" , 10 ,  QFont::Bold));



    ui->checkBox_2->setVisible(false);
    ui->checkBox->setVisible(false);
    ui->settext2->setVisible(false);
    ui->settext1->setVisible(false);
    ui->textcolor->setVisible(false);
    ui->textvisible->setVisible(false);
    ui->label_2->setVisible(false);
    ui->label->setVisible(false);
    ui->savesetting->setVisible(false);

    ui->tableView->setVisible(false);
    if(MainWindow::flag==0){
    rx=MainWindow::x;
    ry=MainWindow::y;
    w=rx*154+2;
    h=ry*154+2;
       defaultpage();
    }
    else {

        loadpage();

    }

}
void Dialog2::loadpage(){

    QString filename=QFileDialog::getOpenFileName(this,
                                              tr("Open Config"),
                                              "",
                                              tr("Config Files (*.ifg)"));
    if (!filename.isNull()){
    QFile config(filename);
    config.open(QFile::ReadOnly | QFile::Text);
    //QString line = config.readLine();


         QTextCodec *codec = QTextCodec::codecForName("GBK");
         while (!config.atEnd())

         {
             QByteArray l = config.readLine();
             QString line = codec->toUnicode(l);
             setting=setting+line;
         }
         qDebug()<<setting;
         QStringList list;
         list=setting.split("##\n##");
         //qDebug()<<list;

    rx=list[0].toInt();
    ry=list[1].toInt();
    ui->textvisible->setText(list[3]);
    ui->textcolor->setText(list[4]);
    textvisible=list[3];
    textcolor=list[4];
    imgurl=list[2];

    list.removeAt(0);
    list.removeAt(0);
    list.removeAt(0);
    list.removeAt(0);
    list.removeAt(0);
    list.removeLast();
    file=list;
    //qDebug()<<list;
    w=rx*154+2;
    h=ry*154+2;
    ui->savesetting->setGeometry(rx*154/2,308,308,154);
    ui->savesetting->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    ui->openimage->setGeometry(rx*154/2,0,154,154);
    ui->openimage->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    ui->openimage->setText(QString::fromLocal8Bit("打开/替换\n图片"));
    ui->preview->setGeometry(rx*154/2+154,0,152,77);
    ui->preview->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    ui->cancelpreview->setGeometry(rx*154/2+154,77,152,77);
    ui->cancelpreview->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    //ui->getsetting->setGeometry(rx*154/2,154,154,154);
    //ui->getsetting->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    //ui->getsetting->setText("载入配置\n文件");
    ui->getsetting->setVisible(false);
    ui->getapp->setGeometry(rx*154/2+154,154,154,77);
    ui->getapp->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    ui->save->setGeometry(rx*154/2+154,231,154,77);
    ui->save->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    ui->save->setVisible(false);
    ui->update->setGeometry(rx*154/2,154,308,154);
    ui->update->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    //this->setFixedSize(rx*77+154,ry*77+152);
    //this->setFixedSize(MainWindow::x*77+306,MainWindow::y*77+152);
    //this->setMinimumHeight(77*ry+300);
    ui->checkBox_2->setVisible(true);
    ui->checkBox->setVisible(true);
    ui->settext2->setVisible(true);
    ui->settext1->setVisible(true);
    ui->textcolor->setVisible(true);
    ui->textvisible->setVisible(true);
    ui->label_2->setVisible(true);
    ui->label->setVisible(true);

    ui->textvisible->setGeometry(10,77*ry+50,77*rx-150,50);
    ui->textcolor->setGeometry(10,77*ry+50+100,77*rx-150,50);
            ui->settext1->setGeometry(77*rx-100,77*ry+50,100,50);
            ui->settext2->setGeometry(77*rx-100,77*ry+50+100,100,50);
            ui->checkBox->setGeometry(77*rx-150,77*ry,500,50);
            ui->checkBox_2->setGeometry(77*rx-150,77*ry+100,500,50);
            ui->label->setGeometry(10,77*ry,500,50);
            ui->label_2->setGeometry(10,77*ry+100,500,50);




    qDebug()<<imgurl;
    p.load(imgurl);
    qDebug()<<p.size();
    imgsize=p.size();

    p=p.scaled(w,h);
    pshow=p.scaled(w/2,h/2);
    qDebug()<<imgurl;
    update();
    this->setFixedSize(rx*77+306,ry*77+152);
    this->setMinimumSize(154,77*ry+250);
    ui->pushButton_2->setGeometry(0,this->height()-30,30,30);
}
    else {
        QMessageBox::critical(nullptr, "Wrong text", "Please Re-enter");
        defaultpage();
        MainWindow::flag2=0;
    }

}
void Dialog2::defaultpage(){
    rx=MainWindow::x;
    ry=MainWindow::y;
    w=rx*154+2;
    h=ry*154+2;
    this->setFixedSize(rx*77+154,ry*77+152);
    //this->setFixedSize(MainWindow::x*77+306,MainWindow::y*77+152);
    this->setMinimumSize(154,308);
    ui->savesetting->setGeometry(rx*154/2,462,308,154);
    ui->savesetting->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    ui->openimage->setGeometry(rx*154/2,0,154,154);
    ui->openimage->setFont(QFont("宋体" , 16 ,  QFont::Bold));
    ui->openimage->setText(QString::fromLocal8Bit("打开/替换\n图片"));
    ui->preview->setGeometry(rx*154/2+154,0,152,77);
    ui->preview->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    ui->cancelpreview->setGeometry(rx*154/2+154,77,152,77);
    ui->cancelpreview->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    ui->getsetting->setGeometry(rx*154/2,154,154,154);
    ui->getsetting->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    ui->getsetting->setText(QString::fromLocal8Bit("载入配置\n文件"));
    ui->getapp->setGeometry(rx*154/2+154,154,154,77);
    ui->getapp->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    ui->save->setGeometry(rx*154/2+154,231,154,77);
    ui->save->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    ui->save->setVisible(false);
    ui->update->setGeometry(rx*154/2,308,308,154);
    ui->update->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    ui->update->setVisible(false);

    ui->textvisible->setGeometry(10,77*ry+50,77*rx-150,50);
    ui->textcolor->setGeometry(10,77*ry+50+100,77*rx-150,50);
            ui->settext1->setGeometry(77*rx-100,77*ry+50,100,50);
            ui->settext2->setGeometry(77*rx-100,77*ry+50+100,100,50);
            ui->checkBox->setGeometry(77*rx-150,77*ry,500,50);
            ui->checkBox_2->setGeometry(77*rx-150,77*ry+100,500,50);
            ui->label->setGeometry(10,77*ry,500,50);
            ui->label_2->setGeometry(10,77*ry+100,500,50);
            ui->pushButton_2->setGeometry(0,this->height()-30,30,30);
}
void Dialog2::paintEvent(QPaintEvent *){

    QPainter painter(this);
    painter.drawPixmap(0,0,pshow);
    if(i>0){
    QPainter p2(this);
    QPen pen;
    pen.setWidth(2);
    p2.setPen(pen);
    //for(int x=0;x<MainWindow::x;x++){
    //    for(int y=0;y<MainWindow::y;y++){
    //        p2.drawRect(2+154*x,2+154*y,152,152);
    //    }
    //}
    for(int x=0;x<rx;x++){
        for(int y=0;y<ry;y++){
            p2.drawRect(1+77*x,1+77*y,76,76);
        }
    }



    }
}
Dialog2::~Dialog2()
{
    delete ui;
}

void Dialog2::on_preview_clicked()
{
    i=1;
    update();
}

void Dialog2::on_cancelpreview_clicked()
{
    i=0;
    update();
}


void Dialog2::on_save_clicked()
{
    ui->savesetting->setVisible(true);
    ui->checkBox_2->setVisible(true);
    ui->checkBox->setVisible(true);
    ui->settext2->setVisible(true);
    ui->settext1->setVisible(true);
    ui->textcolor->setVisible(true);
    ui->textvisible->setVisible(true);
    ui->label_2->setVisible(true);
    ui->label->setVisible(true);

    QStandardItemModel *model = new QStandardItemModel();
    ui->tableView->setModel(model);
    ui->update->setVisible(true);
    model->setHorizontalHeaderItem(0, new QStandardItem("application") );
    model->setHorizontalHeaderItem(1, new QStandardItem("path") );
    model->setHorizontalHeaderItem(2, new QStandardItem("text") );

    if(rx<=8||ry<=8){
    ui->tableView->setColumnWidth(0, 200);
    ui->tableView->setColumnWidth(1, 200);
    ui->tableView->setColumnWidth(2, 200);
    ui->tableView->setVisible(true);
    ui->tableView->setGeometry(0,0,625,616);
    this->setMinimumSize(918,846);
    ui->openimage->setGeometry(8*154/2,0,154,154);
    ui->preview->setGeometry(8*154/2+154,0,152,77);
    ui->getsetting->setGeometry(8*154/2,154,154,154);
    ui->getapp->setGeometry(8*154/2+154,154,154,77);
    ui->save->setGeometry(8*154/2+154,231,154,77);
    ui->cancelpreview->setGeometry(8*154/2+154,77,152,77);
    ui->savesetting->setFont(QFont("Timers" , 16 ,  QFont::Bold));
    if(MainWindow::flag2==0){
        ui->update->setGeometry(8*154/2,308,308,154);
        ui->savesetting->setGeometry(8*154/2,462,308,154);
    }
    else {
        ui->update->setGeometry(8*154/2,154,308,154);
        ui->savesetting->setGeometry(8*154/2,308,308,154);
    }


    ui->label->setGeometry(10,600,400,50);
    ui->label_2->setGeometry(10,700,400,50);
    ui->textvisible->setGeometry(10,650,500,50);
    ui->textcolor->setGeometry(10,750,500,50);
    ui->settext1->setGeometry(520,650,100,50);
    ui->settext2->setGeometry(520,750,100,50);
    ui->checkBox->setGeometry(450,610,500,50);
    ui->checkBox_2->setGeometry(450,710,500,50);
    ui->pushButton_2->setGeometry(0,this->height()-30,30,30);




}
    else{
        ui->tableView->setVisible(true);
        ui->tableView->setGeometry(0,0,77*rx,77*ry);
        ui->tableView->setColumnWidth(0, 77*rx/3);
        ui->tableView->setColumnWidth(1, 77*rx/3);
        ui->tableView->setColumnWidth(2, 77*rx/3);
        ui->pushButton_2->setGeometry(0,this->height()-30,30,30);




    }

for(int i=0;i<file.size();i++){
    first=file[i].lastIndexOf("/");
    name=file[i].right(file[i].length()-first-1);
    first=name.lastIndexOf(".");
    name=name.left(name.length()-(name.length()-first));
    qDebug()<<name;
    first=file[i].lastIndexOf("/");
    path=file[i].left(file[i].length()-(file[i].length()-first-1));
    QString text;
    QString vis="on";
    QString color="light";

    if(textvisible.split(" ").contains(QString::number(i+1))){
            vis="off";
}
    if(textcolor.split(" ").contains(QString::number(i+1))){
            color="dark";
}
    text=vis+"/"+color;
    model->setItem(i, 0, new QStandardItem(name) );
    model->setItem(i, 1, new QStandardItem(path) );
    model->setItem(i, 2, new QStandardItem(text) );

}
cutpicture();
writexml();

}
void Dialog2::cutpicture(){
    for(int i=0;i<file.size();i++){
        first=file[i].lastIndexOf("/");
        name=file[i].right(file[i].length()-first-1);
        first=name.lastIndexOf(".");
        name=name.left(name.length()-(name.length()-first));
        qDebug()<<name;
        first=file[i].lastIndexOf("/");
        path=file[i].left(file[i].length()-(file[i].length()-first-1));
        qDebug()<<path;
        if((i+1)%rx==0){
            x=(i+1)/rx;
            y=rx;
        }
        else {
            x=(i+1)/rx+1;
            y=(i+1)%rx;
        }
        qDebug()<<x;
        qDebug()<<y;

        pic=p.toImage();
        pic=pic.copy(2+154*(y-1),2+154*(x-1),150,150);
        pic.save(path+name+"LOGO.jpg","jpg",100);
    }
}
void Dialog2::writexml(){

    QString color="#7b7b7b";
    for(int i=0;i<file.size();i++){
        QString tilename="on";
        QString tiletext="light";
        if(textvisible.split(" ").contains(QString::number(i+1))){
                tilename="off";
    }
        if(textcolor.split(" ").contains(QString::number(i+1))){
                tiletext="dark";
    }
        first=file[i].lastIndexOf("/");
        name=file[i].right(file[i].length()-first-1);
        first=name.lastIndexOf(".");
        name=name.left(name.length()-(name.length()-first));
        qDebug()<<name;
        first=file[i].lastIndexOf("/");
        path=file[i].left(file[i].length()-(file[i].length()-first-1));
        qDebug()<<path;
        QFile xml(path+name+".VisualElementsManifest.xml");
        xml.open(QFile::WriteOnly | QFile::Text);
        QXmlStreamWriter w(&xml);
        w.setAutoFormatting(true);
        w.writeStartDocument();
        w.writeStartElement("Application");
        w.writeAttribute("xmlns:xns","http://www.w3.org/2001/XMLSchema-instance");
        w.writeStartElement("VisualElements");
        w.writeAttribute("ShowNameOnSquare150x150Logo",tilename);
        w.writeAttribute("Square150x150Logo",name+"LOGO.jpg");
        w.writeAttribute("Square70x70Logo",name+"LOGO.jpg");
        w.writeAttribute("Square44x44Logo",name+"LOGO.jpg");
        w.writeAttribute("ForegroundText",tiletext);
        w.writeAttribute("BackgroundColor",color);
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndDocument();
        xml.close();

    }
}

void Dialog2::on_update_clicked()
{
    if(MainWindow::flag2==1){
        writexml();
        cutpicture();
}
    QProcess q;
    QByteArray username = QDir::home().dirName().toUtf8();
    q.setWorkingDirectory("C:/Windows/system32");
    q.start("powershell");
    q.waitForStarted();
    q.write("Get-Childitem -path 'C:/Users/");
    q.write(username);
    q.write("/AppData/Roaming/Microsoft/Windows/Start Menu/Programs/*lnk' -Recurse | foreach-object { $_.LastWriteTime = Get-Date; $_.CreationTime = Get-Date }");
    q.write("\n\r");
    q.write("Get-Childitem -path 'C:/ProgramData/Microsoft/Windows/Start Menu/programs/*.lnk' -Recurse | foreach-object { $_.LastWriteTime = Get-Date; $_.CreationTime = Get-Date }");
    q.write("\n\r");
    //QThread::sleep(10);
    //q.close();
    if (!q.waitForFinished(10000)) {
            q.kill();
            q.waitForFinished(1);
        }

}

void Dialog2::on_openimage_clicked()
{
    imgurl=openimg.getOpenFileName(this, tr("Open File"),
                                   "",
                                   tr("Images (*.png *.xpm *.jpg)"));

if(imgurl!=""){
    //qDebug()<<imgurl;
    qDebug()<<p;
    p.load(imgurl);
    qDebug()<<p;
    //qDebug()<<p.size();
    imgsize=p.size();

    p=p.scaled(w,h);
    pshow=p.scaled(w/2,h/2);
    //qDebug()<<imgurl;
    update();
    //if(MainWindow::flag==0){
    this->setFixedSize(rx*77+306,ry*77+152);
    this->setMinimumSize(154,77*ry+250);
    ui->tableView->setVisible(false);
    ui->openimage->setGeometry(rx*154/2,0,154,154);
    ui->preview->setGeometry(rx*154/2+154,0,152,77);
    ui->getsetting->setGeometry(rx*154/2,154,154,154);
    ui->getapp->setGeometry(rx*154/2+154,154,154,77);
    ui->save->setGeometry(rx*154/2+154,231,154,77);
    ui->cancelpreview->setGeometry(rx*154/2+154,77,152,77);
    if(MainWindow::flag2==0){
    ui->update->setGeometry(rx*154/2,308,308,154);
    ui->savesetting->setGeometry(rx*154/2,462,308,154);
    ui->pushButton_2->setGeometry(0,this->height()-30,30,30);
    }
    else {
        //ui->update->setVisible(true);
        ui->update->setGeometry(rx*154/2,154,308,154);
        ui->savesetting->setGeometry(rx*154/2,308,308,154);
        ui->pushButton_2->setGeometry(0,this->height()-30,30,30);
    }
}
}

void Dialog2::on_getapp_clicked()
{
    QString s;
    s=nullptr;
    QStringList b;
    QFileDialog get;
QMessageBox:: StandardButton result= QMessageBox::information(nullptr, "Title", QString::fromLocal8Bit("要使用快速导入吗"),QMessageBox::Yes|QMessageBox::No);
    switch (result)
    {

    case QMessageBox::Yes:
        qDebug()<<"Yes";

        file=QFileDialog::getOpenFileNames(this, tr("Open File"),
                                             "",
                                             tr("Application (*.exe *.EXE"));
            for (int i = 0; i < file.size(); i++){
                QString f = file[i];
                qDebug() << "url=" <<f;
                qDebug()<<file.size();
                qDebug()<<rx;
                qDebug()<<ry;

            }
            j=1;
            if(file.size()!=rx*ry)
            {
                j=0;
                QMessageBox::critical(nullptr, "Error", "Please re-select");

            }
            if(j==1){
                ui->save->setVisible(true);
                this->setMinimumSize(154,462);
            }
            else{
                ui->save->setVisible(false);
                ui->update->setVisible(false);
                ui->savesetting->setVisible(false);
            }

        break;
    case QMessageBox::No:
        qDebug()<<"NO";

        for(int i=0;i<rx*ry;i++){
            QString num;
            num=QString::fromLocal8Bit("请选择第")+QString::number(i/rx+1)+QString::fromLocal8Bit("行，第")+QString::number(i%rx+1)+QString::fromLocal8Bit("列的应用");
            QString f=get.getOpenFileName(this, num,
                                                 "",
                                                 tr("Application (*.exe *.EXE"));

            s=s+"@@@"+f;
            if(f==""){
                break;
            }

        }

        b=s.split("@@@");
        b.removeAt(0);
        file=b;
        qDebug()<<file;
        j=1;
        if(file.size()!=rx*ry)
        {
            j=0;
            QMessageBox::critical(nullptr, "Error", "Please re-select");

        }
        if(j==1){
            ui->save->setVisible(true);
            this->setMinimumSize(154,462);
        }
        else{
            ui->save->setVisible(false);
            ui->update->setVisible(false);
            ui->savesetting->setVisible(false);
        }
        break;
    default:
        break;

    }

}

void Dialog2::on_getsetting_clicked()
{
    MainWindow::flag=1;
    MainWindow::flag2=1;
    Dialog2::reject();
    Dialog2 d;

    MainWindow::flag=0;
    d.exec();

}

void Dialog2::on_savesetting_clicked()
{
    QString fileName = QFileDialog::getSaveFileName(this,
            tr("Open Config"),
            "",
            tr("Config Files (*.ifg)"));

        if (!fileName.isNull())
        {
            QFile config(fileName);
            config.open(QFile::WriteOnly | QFile::Text);
            QTextStream ifg(&config);
            ifg<<"\n"<<rx<<"##\n##";
            ifg<<ry<<"##\n##";
            ifg<<imgurl<<"##\n##";
            ifg<<textvisible<<"##\n##";
            ifg<<textcolor<<"##\n##";
            for(int i=0;i<file.size();i++){
               ifg<<file[i]<<"##\n##";
            }
            config.close();


        }
        else {
            QMessageBox::critical(nullptr, "Wrong text", "Please Re-enter");

        }

}

void Dialog2::on_checkBox_stateChanged(int arg1)
{
   if(arg1>0){
       qDebug()<<"yes";
    QString a;
    for(int i=1;i<=file.size();i++){
        QString b=QString::number(i);
        a=a+b+" ";
        //ui->textvisible->setText(a+" ");
    }
    ui->textvisible->setText(a);
    textvisible=a;
   }
   else {
       qDebug()<<"no";
       ui->textvisible->setText(nullptr);
       textvisible=nullptr;
   }

}

void Dialog2::on_checkBox_2_stateChanged(int arg2)
{
    if(arg2>0){
     QString a;
     for(int i=1;i<=file.size();i++){
         QString b=QString::number(i);
         a=a+b+" ";
         //ui->textvisible->setText(a+" ");
     }
     ui->textcolor->setText(a);
     textcolor=a;
    }
    else {
        ui->textcolor->setText(nullptr);
        textcolor=nullptr;
    }

}

void Dialog2::on_settext1_clicked()
{
    textvisible=ui->textvisible->text();
    on_save_clicked();
}

void Dialog2::on_settext2_clicked()
{
    textcolor=ui->textcolor->text();
    on_save_clicked();
}
void Dialog2::keyPressEvent(QKeyEvent *ev){

    if(ev->key() == Qt::Key_F8)
    {
        evv++;
       qDebug()<<"haha";

       if(evv%2==0){
       ui->pushButton->setGeometry(0,0,this->width(),this->height());
       ui->pushButton->setFont(QFont("Timers" , 20 ,  QFont::Bold));
       ui->pushButton->setVisible(true);
       }
       else{
           ui->pushButton->setVisible(false);
       }
    }
    if(ev->key() == Qt::Key_F7){
        evv++;
        if(evv%2==0){
        ui->pushButton_3->setGeometry(0,0,this->width(),this->height());
        ui->pushButton_3->setFont(QFont("Timers" , 20 ,  QFont::Bold));
        ui->pushButton_3->setVisible(true);
    }
        else{
            ui->pushButton_3->setVisible(false);
        }
}
}




void Dialog2::on_pushButton_clicked()
{
    if(file.isEmpty()==true||p.isNull()==true){
         QMessageBox::critical(nullptr, QString::fromLocal8Bit("没有路径和文件被加载"), QString::fromLocal8Bit("请先导入图片和应用"));
    }
    else{

        std::random_shuffle(file.begin(), file.end());
        on_save_clicked();
        writexml();
        cutpicture();
        on_update_clicked();
        //writexml();
        //update();
    }
}

void Dialog2::on_pushButton_2_clicked()
{
    about s;
    s.exec();
}

void Dialog2::on_pushButton_3_clicked()
{
    for(int i=0;i<file.size();i++){
        QString tilename="on";
        QString tiletext="light";
        if(textvisible.split(" ").contains(QString::number(i+1))){
                tilename="off";
    }
        if(textcolor.split(" ").contains(QString::number(i+1))){
                tiletext="dark";
    }
        first=file[i].lastIndexOf("/");
        name=file[i].right(file[i].length()-first-1);
        first=name.lastIndexOf(".");
        name=name.left(name.length()-(name.length()-first));
        qDebug()<<name;
        first=file[i].lastIndexOf("/");
        path=file[i].left(file[i].length()-(file[i].length()-first-1));
        qDebug()<<path;
        QFile xml(path+name+".VisualElementsManifest.xml");
        xml.open(QFile::WriteOnly | QFile::Text);
        QXmlStreamWriter w(&xml);
        w.setAutoFormatting(true);

        xml.close();

    }
    QProcess q;
    QByteArray username = QDir::home().dirName().toUtf8();
    q.setWorkingDirectory("C:/Windows/system32");
    q.start("powershell");
    q.waitForStarted();
    q.write("Get-Childitem -path 'C:/Users/");
    q.write(username);
    q.write("/AppData/Roaming/Microsoft/Windows/Start Menu/Programs/*lnk' -Recurse | foreach-object { $_.LastWriteTime = Get-Date; $_.CreationTime = Get-Date }");
    q.write("\n\r");
    q.write("Get-Childitem -path 'C:/ProgramData/Microsoft/Windows/Start Menu/programs/*.lnk' -Recurse | foreach-object { $_.LastWriteTime = Get-Date; $_.CreationTime = Get-Date }");
    q.write("\n\r");
    //QThread::sleep(10);
    //q.close();
    if (!q.waitForFinished(10000)) {
            q.kill();
            q.waitForFinished(1);
        }
}
