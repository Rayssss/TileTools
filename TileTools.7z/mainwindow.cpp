#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QDebug"
#include "QIntValidator"
#include "QMessageBox"
#include "dialog2.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    x=0;
    y=0;
    flag=0;
    ui->setupUi(this);
    setWindowFlags(windowFlags()& ~Qt::WindowMaximizeButtonHint);
    setFixedSize(this->width(), this->height());
    ui->lineEdit->setFont(QFont("Timers" , 28 ,  QFont::Bold));
    ui->lineEdit->setValidator(new QIntValidator(ui->lineEdit));
    ui->lineEdit->setAlignment(Qt::AlignCenter);
    ui->lineEdit_2->setFont(QFont("Timers" , 28 ,  QFont::Bold));
    ui->lineEdit_2->setValidator(new QIntValidator(ui->lineEdit));
    ui->lineEdit_2->setAlignment(Qt::AlignCenter);

            QString b=("31 sda");
            QStringList a;
            a=b.split(" ");
            qDebug()<<a;
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{

    MainWindow::flag2=0;
    x=ui->lineEdit->text().toInt();
    y=ui->lineEdit_2->text().toInt();
    qDebug()<<x;
    qDebug()<<y;
    Dialog2 d1;

    if (x<=0||y<=0){


    QMessageBox::critical(nullptr, "Wrong number", "Please Re-enter");
    }
    else
    d1.exec();

}
